const express = require('express');
const app = express();
const cors = require('cors');

const { config } = require('./config/index');
const videosAPI = require('./routes/videos');
const corsOptions = { origin : ["http://localhost:4200", "https://app-votos-albertopedrero.vercel.app/"]}; 

app.use(cors(corsOptions));

app.use(express.json());
videosAPI(app);


app.listen(config.port, () => {
    console.log(`servidor escuchando en ${config.port}`);
})