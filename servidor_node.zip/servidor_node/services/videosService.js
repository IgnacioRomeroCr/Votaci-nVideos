const MongoLib = require('../lib/mongo');

class VideosService {

    constructor(){
        this.collection = 'videos';
        this.mongoDB = new MongoLib();
    }

    async getVideos() {
        const videos = await this.mongoDB.getVideos(this.collection);
        return videos || [];
    }

    async addVideo(video){
        const videoCreadoId = await this.mongoDB.addVideo(this.collection, video);
        return videoCreadoId || [];
    }
    async actualizarVotos(videoId, actualizacion) {
        const actualizado = await this.mongoDB.actualizarVotos(this.collection, videoId, actualizacion);
        return actualizado || [];
    }
    async deleteVideo(videoId){
        const borrado = await this.mongoDB.deleteVideo(this.collection, videoId);
        return borrado || [];
    }
    
}

module.exports = VideosService