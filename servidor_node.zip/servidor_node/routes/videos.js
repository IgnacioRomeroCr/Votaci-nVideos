const express = require('express');
const VideosService = require('../services/videosService');
/* GET home page. */
function videosAPI(app){
  const router = express.Router();


  app.use('/api/videos', router);

  const videosService = new VideosService();
  router.get('/', async (req, res, next) => {
    try {
      const videos = await  videosService.getVideos();
      res.status(200).json(
          {
              data: videos,
              message: 'videos devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.post('/', async (req, res, next) => {
    const {body: video} = req;
    try {
      const nuevoVideo = await  videosService.addVideo(video);
      res.status(200).json(
          {
              data: nuevoVideo,
              message: 'video añadido con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.put('/:videoId', async function (req, res, next) {
    const  {videoId}  = req.params;
    const  actualizacion  = req.body; 

    try {
        const videoActualizado = await videosService.actualizarVotos(videoId, actualizacion);

        res.status(200).json({
            data: videosAPI,
            message: 'video actualizada con éxito'
        });
    } catch (err) {
        next(err);
    }

});
router.delete('/:videoId', async function (req, res, next) {
  const  {videoId}  = req.params;
  
    try {
    const videoBorrado = await videosService.deleteVideo(videoId);

    res.status(200).json({
        data: videosAPI,
        message: 'borrado correctamente'
    });
} catch (err) {
    next(err);
}

});

}
module.exports = videosAPI;
